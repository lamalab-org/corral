pair_style      hybrid/overlay buck/coul/long 8.0 12.0 
pair_coeff      * * buck/coul/long 0.0 1.0 0.0
pair_coeff      1 3 buck/coul/long 101093.3472    0.243838  707.96963 #Na-O
pair_coeff      2 3 buck/coul/long 316001.3219145 0.193817  1260.9930729 #Si-O
pair_coeff      3 3 buck/coul/long 42541.49842    0.343645  4441.068122 #O-O
kspace_style    pppm 1.0e-4

