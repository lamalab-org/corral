# Resistor Network Environment — v3

Infer a full resistor network from sparse effective-resistance measurements.
The saved banks have ten structurally distinct tasks per level. Static JSON
under `environments/level_*/tasks_json/` is what the runtime serves; changing
the sampler alone does not change those tasks.

The evaluated v2 environment, task banks, tests, figures, and run audit are
preserved in `archives/resistor_network_v2_20261010.zip`. Its `manifest.json`
contains SHA-256 hashes of every archived file. Existing v2 run reports remain
in their original external run directories. Their task IDs refer to the v2
bank, not these regenerated v3 inputs.

## Difficulty and public inputs

| Property | Level 1 | Level 2 |
|---|---|---|
| Resistors | 18–26 | 30–42 |
| Structure, private to generation | 2–3 coupled modules sharing articulation nodes | One biconnected core, minimum node degree 3 |
| Construction | Random cycle-and-chord modules | Random cubic graphs with additional chords |
| Published measurements | 23–33 | 38–53 |
| Default/saved seed | 202610103 | 202610104 |

Both levels use positive real-valued resistances. There is **no allowed-value
pool**, no requirement to round to standard resistor values, and no public
sampling range. Internal values are sampled logarithmically between 10 and
200 ohms; this is a sampling choice, not a submission constraint.

Agents receive only effective-resistance observations, the component count,
and the physical/submission rules needed to interpret and score them:

- Exactly the named nodes and resistor count; positive finite ideal resistors.
- A connected simple graph: no self-loops or direct parallel edges.
- Measurements rounded to three decimal places, in ohms.
- Arbitrary resistor IDs and unrestricted connections between named nodes.
- Every supplied reading must be reproduced within 0.000500001 ohms.

There are no topology-family, construction-order, terminal-tail, candidate-edge,
resistor-range, or resistor-pool hints. All nodes appear in the observations, so
a separate node inventory is unnecessary. A value list is not required when
the scorer accepts continuous values and observationally equivalent circuits.

## Sparse measurement policy

For `m` resistors, publish `m + ceil(m / 4)` pairs. Continuous value recovery on
fixed wiring needs at least `m` independent scalar observations locally; the
additional observations constrain wiring and protect against accidental fits.
This budget is a practical sparse policy, not a theorem that every observation
is indispensable or that global topology is unique.

The selector draws random subsets of **all** node pairs, always including A–B.
It does not seed the subset with physical edge pairs. Accepted subsets satisfy:

- Every node appears at least twice, and no node has a complete probe star.
- At most half of all possible pairs are measured.
- At least `ceil(m / 3)` physical edge pairs remain unmeasured.
- The log-value measurement Jacobian has full column rank.
- The first-order worst-case rounding error in log values is below one quarter
  of the existing 2% offline value-recovery tolerance.

Rank and stability screening use the hidden topology offline. This checks that
values are locally observable; it does not reveal adjacency to the agent or
certify global uniqueness. Measurements come from the nodal simulator.

All 20 saved ground truths pass the simulation scorer. Independently fitting
values on their supplied wiring from a uniform 47-ohm start also passes every
reading on all 20 tasks; results are in
`analysis/resistor_network_v3_known_wiring_check.json`. The fit respects the
rounding intervals, since minimizing squared error alone can put an individual
prediction outside its allowed interval. These checks establish feasibility
and conditional value recovery, not practical discovery of unknown wiring.

Generation also checks sensitivity to opening and shorting every resistor,
performs a continuous fit on known wiring from a fixed 47-ohm start, and checks
up to 24 single-edge rewires over **all** visible pairs with joint value refits
from two starts. Demonstrated ambiguities are rejected. The audit records its
coverage and `exhaustive: false`; unknown equivalent networks are accepted by
the scorer rather than penalized against the private answer.

The previous public-pair convex reconstruction is no longer a generation
acceptance condition. Legacy numerical helpers remain in source for archived
diagnostics, but are not exposed to agents in the v3 bank.

## Tools and scoring

V3 tasks expose `simulate_circuit_resistance` for a single supplied node pair
and `validate_circuit_topology` for structural checks, plus standard workspace
tools and submission. The tools operate on the agent's proposed circuit;
they never measure the hidden circuit. There is no fitting, topology-proposal,
or batch measurement-validation tool in the task tool list.

Native coding agents may still write numerical solvers using their own shell
capabilities. Removing an environment fitting tool does not prohibit native
computation, and reported Corral tool counts need not include native calls.

Submit a JSON string, for example:

```json
{"resistors":{"r1":31.284,"r2":74.193},"connections":[["A","N1","r1"],["N1","B","r2"]]}
```

`sparse_circuit_solution` returns 1 only after checking JSON structure,
duplicate keys, positive finite values, exactly-once resistor use, component
count, exact node set, unique node-pair edges, and connectivity, then independently
simulating **every** public reading. Each individual absolute residual must be
at most 0.000500001 ohms. There is no aggregate-error shortcut, relative-error
allowance, discrete snapping, or requirement to match the private wiring.

This scores identification of a circuit consistent with the experiment.
It does not claim that accepted wiring is necessarily the original wiring.
The legacy `resistor_conductance` scorer is retained for replaying v2 tasks.

## Setup and generation

```bash
cd tasks/resistor_network
uv sync
uv run python environments/level_1/generate_tasks.py --seed 202610103
uv run python environments/level_2/generate_tasks.py --seed 202610104
uv run pytest tests
```

Each generator requires exactly ten tasks and generates the full batch before
replacing its saved bank. Seeds reproduce content except UUIDs. Archive a bank
before regenerating if you need to reproduce reports referring to its task IDs.

From the repository root:

```bash
uv run corral bench --environment resistor_network \
  --env-kwargs '{"level": 2}' --agent react --list-tasks
```

Remove `--list-tasks` and specify your agent/model to run. Compare levels with
the same model, agent, reasoning settings, tool access, and budgets; record task
hashes and benchmark version. These changes close the observed v2 shortcut,
but v3 agent success rates still require fresh benchmark runs.

## Inspection and figures

```bash
uv run python -m resistor_network.visualize environments/level_1/tasks_json --out figures/level_1
uv run python -m resistor_network.visualize environments/level_2/tasks_json --out figures/level_2
```

Historical v2 overview/comparison plots and diagnostics are in the archive.
Current task plots can be regenerated with the commands above. The v2 run-audit
script is also archived; its pool-snapping and candidate-support assumptions
are specific to that bank.

The prepared v3 plots are in `figures/v3/`: two overview PNGs, twenty individual
PNGs with exact-value tables, and `all_circuits.pdf` containing all twenty
circuits. From the repository root, regenerate them with:

```bash
tasks/resistor_network/.venv/bin/python analysis/plot_resistor_network_v3.py
```

`analysis/resistor_network_v3_audit.json` records the saved-bank hashes and an
offline adaptation of the old shortcut: fit all measured pairs, prune to the
public resistor count, then refit continuous values and simulate every reading.
It scores 0/20 on v3; all 20 ground truths pass. This closes the tested shortcut,
not every possible numerical solver. The environment suite passes 274 tests.
The launch script now defaults to a separate `resistor_network_v3` output root
and versioned run IDs to keep fresh reports separate from the v2 results.

## Calibration bank

`calibration/20261010/` is a separate, frozen six-task bank. Level 1 has
12, 14, and 16 resistors; level 2 has 18, 21, and 24. It uses
`m + ceil(m / 2)` readings, continuous values, and the same tools, prompt
format, and simulation scorer as v3. Level 1 keeps two coupled modules with
enough nodes for balanced sparse readings. Level 2 keeps one biconnected core
of minimum degree three, allowing cycle rank seven for the smaller core.
The original v3 task banks remain unchanged. The calibration manifest records
seeds, configuration, hashes, and successful ground-truth/known-wiring checks.

Generate a new calibration directory with
`analysis/generate_resistor_calibration.py --output PATH` using the task
virtualenv. The script refuses to overwrite an existing bank.

`bash run_scripts/launch_resistor_calibration.sh` runs one trial on each of
the six tasks for ReAct GPT-5.6-Sol and ReAct Opus-5.5 (batch A), followed by
Codex GPT-5.6-Sol and Claude Code Opus-5.5 (batch B): 24 trials total.
ReAct responses are capped at 16,000 tokens with a 600-second request timeout;
native agents have a 900-second wall-clock limit per trial. Reasoning effort
is medium. Results go to
`/data/alamparan/corral_psychometric_runs/resistor_network_calibration_20261010/`.

### Published 30-value calibration

`calibration/20261010_pool30/` pairs each continuous calibration task with the
same labeled wiring, component count, and measured pairs. Hidden resistor
values are mapped to the nearest value in a fixed list of 30 values spanning
10–200 ohms, and readings are recomputed. The entire list is public; values
may repeat, and no per-value inventory is disclosed. Tools and structural
hints are unchanged. The scorer enforces the published pool and independently
simulates every reading, accepting equivalent valid wiring within that domain.

Generate this variant with `analysis/generate_resistor_pool_calibration.py
--source calibration/20261010 --output PATH` using the task virtualenv and
paths relative to your working directory. It checks full local Jacobian rank,
rounding stability, resistor sensitivity, ground-truth scoring, and successful
known-wiring fitting followed by snapping to the public list. These are
feasibility checks, not proof of practical blind recovery or global uniqueness.

`bash run_scripts/launch_resistor_pool30.sh` runs eight smoke trials on
`task_0` of both levels with the same four agents and budgets as the continuous
calibration. Outputs use the separate
`resistor_network_calibration_pool30_20261010/smoke/` directory.
