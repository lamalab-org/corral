"""Create a separate six-task calibration bank without changing the v3 bank."""

import argparse
import hashlib
import json
import random
import sys
from dataclasses import asdict
from pathlib import Path

import networkx as nx

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tasks/resistor_network/src")]
# ruff: noqa: E402, T201
from resistor_network.env import get_scoring_function, load_tasks_from_json
from resistor_network.sampler import LevelConfig
from resistor_network.sparse import build_sparse_task, fit_known_wiring

CONFIGS = {
    1: LevelConfig(
        1,
        "modular_bridges",
        (12, 16),
        max_tail_edges=0,
        measurement_redundancy_divisor=2,
        module_node_fraction=0.70,
    ),
    2: LevelConfig(
        2,
        "coupled_core",
        (18, 24),
        max_tail_edges=0,
        measurement_redundancy_divisor=2,
        min_core_cycle_rank=7,
    ),
}
SIZES = {1: [12, 14, 16], 2: [18, 21, 24]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite existing bank: {args.output}")
    args.output.mkdir(parents=True)
    manifest = {
        "bank": "resistor_network_calibration_20261010",
        "scope": "Smaller public-input calibration; feasibility is verified, blind recovery is not guaranteed.",
        "measurement_formula": "m + ceil(m / 2)",
        "configs": {level: asdict(config) for level, config in CONFIGS.items()},
        "tasks": [],
    }
    for level, config in CONFIGS.items():
        seed = 202610105 + level
        rng = random.Random(seed)
        folder = args.output / f"level_{level}" / "tasks_json"
        folder.mkdir(parents=True)
        graphs = []
        for index, count in enumerate(SIZES[level]):
            for _ in range(100):
                task = build_sparse_task(rng, config, index, count)
                truth = task["scoring_params"]["expected_topology"]
                graph = nx.Graph([c[:2] for c in truth["connections"]])
                if any(nx.is_isomorphic(graph, old) for old in graphs):
                    continue
                graphs.append(graph)
                break
            else:
                raise RuntimeError("Could not find a distinct calibration circuit")
            task["sampling_metadata"].update(
                bank=manifest["bank"],
                batch_seed=seed,
                calibration_config=asdict(config),
            )
            readings = task["initial_input"]["measurements"]
            scorer = get_scoring_function(
                task["scoring_function"], task["scoring_params"]
            )
            fitted = fit_known_wiring(truth, readings, respect_rounding=True)
            assert scorer(json.dumps(truth)) == 1
            assert scorer(json.dumps(fitted["topology"])) == 1
            assert len(readings) == count + (count + 1) // 2
            path = folder / f"task_{index}.json"
            path.write_text(json.dumps([task], indent=2) + "\n")
            record = {
                "level": level,
                "id": task["id"],
                "resistors": count,
                "nodes": len(graph),
                "measurements": len(readings),
                "cycle_rank": count - len(graph) + 1,
                "ground_truth_score": 1,
                "known_wiring_fit_score": 1,
                "known_wiring_max_error": fitted["max_absolute_error"],
                "path": str(path.relative_to(args.output)),
                "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            }
            manifest["tasks"].append(record)
            print(json.dumps(record), flush=True)
        assert len(load_tasks_from_json(folder)) == 3
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    main()
