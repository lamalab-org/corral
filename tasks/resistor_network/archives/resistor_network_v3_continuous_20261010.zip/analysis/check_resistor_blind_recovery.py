"""Budgeted sparse-conductance search using public observations only.

Failure is inconclusive: this is a heuristic, not an impossibility certificate.
Private scoring parameters are read only after search to validate its output.
"""

# ruff: noqa: T201

import argparse
import itertools
import json
import sys
import time
from pathlib import Path

import numpy as np
from scipy.optimize import least_squares

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tasks/resistor_network/src")]
from resistor_network.env import get_scoring_function  # noqa: E402
from resistor_network.sparse import fit_known_wiring  # noqa: E402


def search(public, seconds, seed):
    observations = public["measurements"]
    count = int(public["notes"][0].split()[3])
    nodes = sorted({m[k] for m in observations for k in ("node_a", "node_b")})
    pairs = list(itertools.combinations(nodes, 2))
    index = {n: i for i, n in enumerate(nodes)}
    incidence = np.zeros((len(nodes) - 1, len(pairs)))
    probes = np.zeros((len(observations), len(nodes) - 1))
    for j, pair in enumerate(pairs):
        for n, sign in zip(pair, (1, -1), strict=True):
            if index[n] < len(nodes) - 1:
                incidence[index[n], j] = sign
    for j, obs in enumerate(observations):
        for n, sign in ((obs["node_a"], 1), (obs["node_b"], -1)):
            if index[n] < len(nodes) - 1:
                probes[j, index[n]] = sign
    targets = np.array([m["resistance"] for m in observations])
    scale = 1 / np.median(targets)
    rng = np.random.default_rng(seed)
    started = time.monotonic()
    best = None
    attempts = 0

    def response(g):
        if time.monotonic() - started > seconds:
            raise TimeoutError
        voltage = np.linalg.solve((incidence * g) @ incidence.T, probes.T).T
        return np.sum(voltage * probes, axis=1), -((voltage @ incidence) ** 2)

    try:
        while time.monotonic() - started < seconds:
            g = np.exp(rng.normal(0, 0.7, len(pairs))) / (
                len(nodes) * np.median(targets) / 2
            )
            weights = np.ones(len(pairs))
            for penalty in (0.003, 0.001, 0.0003, 0.0001, 0.00003):
                root = np.sqrt(penalty * weights)

                def residual(values, root=root):
                    pred, _ = response(values)
                    return np.r_[(pred - targets) * scale, root * values]

                def jacobian(values, root=root):
                    _, jac = response(values)
                    return np.vstack((jac * scale, np.diag(root)))

                result = least_squares(
                    residual,
                    g,
                    jac=jacobian,
                    bounds=(1e-10, np.inf),
                    max_nfev=100,
                    ftol=1e-9,
                    gtol=1e-9,
                    xtol=1e-9,
                )
                g = result.x
                selected = np.argsort(g)[-count:]
                candidate = {
                    "resistors": {
                        f"r{i}": float(1 / g[j]) for i, j in enumerate(selected)
                    },
                    "connections": [
                        [*pairs[j], f"r{i}"] for i, j in enumerate(selected)
                    ],
                }
                try:
                    fitted = fit_known_wiring(
                        candidate, observations, list(candidate["resistors"].values())
                    )
                    attempts += 1
                    if (
                        best is None
                        or fitted["max_absolute_error"] < best["max_absolute_error"]
                    ):
                        best = fitted
                        print(
                            f"seed={seed} fits={attempts} max_error={best['max_absolute_error']:.6g}",
                            flush=True,
                        )
                    if best["max_absolute_error"] <= 0.000500001:
                        return best, attempts, time.monotonic() - started
                except (ValueError, np.linalg.LinAlgError):
                    pass
                weights = 1 / (g + max(np.median(g), 1e-6)) ** 2
                weights /= np.median(weights)
    except TimeoutError:
        pass
    return best, attempts, time.monotonic() - started


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seconds", type=float, default=120)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    records = []
    for level in (1, 2):
        path = (
            ROOT
            / f"tasks/resistor_network/environments/level_{level}/tasks_json/task_0.json"
        )
        task = json.loads(path.read_text())[0]
        fitted, attempts, elapsed = search(
            task["initial_input"], args.seconds, 100 + level
        )
        scorer = get_scoring_function(task["scoring_function"], task["scoring_params"])
        records.append(
            {
                "level": level,
                "task": "task_0",
                "seconds": elapsed,
                "fits": attempts,
                "score": scorer(json.dumps(fitted["topology"])) if fitted else 0,
                "result": fitted,
            }
        )
        args.output.write_text(
            json.dumps({"scope": __doc__, "records": records}, indent=2) + "\n"
        )


if __name__ == "__main__":
    main()
