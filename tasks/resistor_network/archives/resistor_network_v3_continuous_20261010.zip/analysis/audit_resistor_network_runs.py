"""Audit saved evaluation results and test public-input recovery baselines.

Run with the repository virtualenv. Writes JSON to stdout; does not alter banks.
"""

import argparse
import ast
import json
import sys
from collections import Counter
from pathlib import Path
from time import perf_counter

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tasks/resistor_network/src")]

# Bootstrap local packages before importing the environment.
# ruff: noqa: E402, T201
from resistor_network.sampler import RESISTOR_POOL, reconstruct_from_measurements
from resistor_network.score import check_conductance_topology
from resistor_network.tools import estimate_resistor_values


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runs", type=Path, required=True)
    parser.add_argument(
        "--output", type=Path, help="Save JSON directly, avoiding library stdout logs"
    )
    args = parser.parse_args()
    output = {"runs": [], "tasks": [], "public_inputs_match": []}
    for report in sorted(args.runs.glob("level_*/*/report.json")):
        data = json.loads(report.read_text())
        trials = [
            (task, index + 1, trial)
            for task, result in data["task_results"].items()
            for index, trial in enumerate(result["trials"])
        ]
        tools = Counter()
        failures = []
        for task, index, trial in trials:
            tools.update(trial.get("by_tool", {}))
            score = (trial.get("evaluation") or {}).get("score")
            if score != 1:
                failures.append(
                    {
                        "task": task,
                        "trial": index,
                        "score": score,
                        "error": trial.get("error_message"),
                    }
                )
        output["runs"].append(
            {
                "run": report.parent.name,
                "successes": len(trials) - len(failures),
                "trials": len(trials),
                "mean_seconds": data["metrics"]["Overall Average Duration"],
                "corral_tool_calls": dict(tools),
                "failures": failures,
            }
        )
        # Compare each task's captured public prompt with today's static bank.
        level = int(report.parent.parent.name.split("_")[1])
        for task in data["task_results"]:
            snapshot = report.parent / f"task-{task}/k-1/state-snapshots/final.json"
            if not snapshot.exists():
                continue
            trace = json.loads(snapshot.read_text())
            prompt = trace["task"]["metadata"]["prompt"]
            bank = (
                ROOT
                / f"tasks/resistor_network/environments/level_{level}/tasks_json/{task}.json"
            )
            current = json.loads(bank.read_text())[0]["initial_input"]
            matches = all(
                ast.literal_eval(prompt.split(f"- {key}: ", 1)[1].split("\n", 1)[0])
                == value
                for key, value in current.items()
            )
            output["public_inputs_match"].append(
                {"run": report.parent.name, "task": task, "match": matches}
            )
        del data

    for level in (1, 2):
        for path in sorted(
            (
                ROOT / f"tasks/resistor_network/environments/level_{level}/tasks_json"
            ).glob("*.json")
        ):
            task = json.loads(path.read_text())[0]
            measurements = task["initial_input"]["measurements"]
            # Only public inputs feed either recovery method. Hidden topology is
            # used afterward to evaluate, never to select or fit candidate edges.
            count = int(task["initial_input"]["notes"][0].split()[3])
            pairs = [(m["node_a"], m["node_b"]) for m in measurements]
            nodes = {n for pair in pairs for n in pair}
            candidate = {
                "resistors": {f"R{i}": 20 for i in range(1, len(pairs) + 1)},
                "connections": [[a, b, f"R{i}"] for i, (a, b) in enumerate(pairs, 1)],
            }
            started = perf_counter()
            fit = json.loads(
                estimate_resistor_values.execute(
                    topology=json.dumps(candidate),
                    measurements=json.dumps(measurements),
                )
            )
            fit_seconds = perf_counter() - started
            fitted = fit.get("resistors", {})
            selected = sorted(fitted, key=fitted.get)[:count]
            snapped = {
                "resistors": {
                    rid: min(RESISTOR_POOL, key=lambda r: abs(r - fitted[rid]))
                    for rid in selected
                },
                "connections": [
                    c for c in candidate["connections"] if c[2] in selected
                ],
            }
            scorer = check_conductance_topology(**task["scoring_params"])
            fit_score = scorer(json.dumps(snapped)) if fitted else 0
            started = perf_counter()
            recovery = reconstruct_from_measurements(measurements, count)
            recovery_seconds = perf_counter() - started
            output["tasks"].append(
                {
                    "level": level,
                    "task": task["id"],
                    "resistors": count,
                    "nodes": len(nodes),
                    "measurements": len(pairs),
                    "possible_pairs": len(nodes) * (len(nodes) - 1) // 2,
                    "candidate_fit_score": fit_score,
                    "candidate_fit_seconds": fit_seconds,
                    "candidate_fit_info": fit.get("optimization_info"),
                    "convex_recovery_score": scorer(json.dumps(recovery["topology"]))
                    if recovery.get("recovered")
                    else 0,
                    "convex_recovery_seconds": recovery_seconds,
                    "rounding_gap_fraction": task["sampling_metadata"][
                        "ambiguity_audit"
                    ]["rounding_stability"]["max_gap_fraction"],
                }
            )
            print(
                f"L{level} {task['id']}: candidate-fit score={fit_score}",
                file=sys.stderr,
                flush=True,
            )
    serialized = json.dumps(output, indent=2) + "\n"
    if args.output:
        args.output.write_text(serialized)
    else:
        print(serialized, end="")


if __name__ == "__main__":
    main()
