"""Check v3 saved banks and the old measured-pair fitting shortcut.

Uses only public measurements and component count for the shortcut. Hidden
wiring is used solely for diagnostics and validating the saved ground truth.
Run with the resistor environment's virtualenv and --output PATH.
"""

import argparse
import hashlib
import json
import sys
from pathlib import Path
from time import perf_counter

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tasks/resistor_network/src")]
# Bootstrap local packages before imports.
# ruff: noqa: E402, T201
from resistor_network.env import get_scoring_function
from resistor_network.sparse import fit_known_wiring


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    records = []
    for path in sorted(
        (ROOT / "tasks/resistor_network/environments").glob("level_*/tasks_json/*.json")
    ):
        task = json.loads(path.read_text())[0]
        measurements = task["initial_input"]["measurements"]
        # Read the count from the public note, not private scoring parameters.
        count = int(task["initial_input"]["notes"][0].split()[3])
        pairs = [(m["node_a"], m["node_b"]) for m in measurements]
        nodes = {n for pair in pairs for n in pair}
        scorer = get_scoring_function(task["scoring_function"], task["scoring_params"])
        candidate = {
            "resistors": {f"r{i}": 47.0 for i in range(len(pairs))},
            "connections": [[a, b, f"r{i}"] for i, (a, b) in enumerate(pairs)],
        }
        started = perf_counter()
        result = {"score": 0, "error": None}
        try:
            fitted = fit_known_wiring(candidate, measurements)
            values = fitted["topology"]["resistors"]
            selected = set(sorted(values, key=values.get)[:count])
            pruned = {
                "resistors": {rid: values[rid] for rid in selected},
                "connections": [
                    c for c in candidate["connections"] if c[2] in selected
                ],
            }
            # A stronger continuous adaptation of v2's snap-and-prune shortcut:
            # refit retained edges and score by simulation, without a value pool.
            refitted = fit_known_wiring(pruned, measurements)
            result.update(
                score=scorer(json.dumps(refitted["topology"])),
                max_absolute_error=refitted["max_absolute_error"],
            )
        except ValueError as exc:
            result["error"] = str(exc)
        result["seconds"] = perf_counter() - started
        record = {
            "level": task["level"],
            "task": task["id"],
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "resistors": count,
            "nodes": len(nodes),
            "measurements": len(pairs),
            "possible_pairs": len(nodes) * (len(nodes) - 1) // 2,
            "unmeasured_physical_edges": task["sampling_metadata"][
                "measurement_policy"
            ]["unmeasured_physical_edges"],
            "ground_truth_score": scorer(
                json.dumps(task["scoring_params"]["expected_topology"])
            ),
            "measured_pair_shortcut": result,
        }
        records.append(record)
        print(
            f"L{task['level']} {task['id']}: shortcut score={result['score']}",
            file=sys.stderr,
            flush=True,
        )
    args.output.write_text(
        json.dumps(
            {
                "benchmark_version": 3,
                "scope": "One measured-pair fit, prune to public count, continuous refit; no hidden wiring in baseline. Not an agent evaluation or global hardness proof.",
                "tasks": records,
            },
            indent=2,
        )
        + "\n"
    )


if __name__ == "__main__":
    main()
