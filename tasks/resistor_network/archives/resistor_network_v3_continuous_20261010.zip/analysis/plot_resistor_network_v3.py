"""Plot the current banks as overview PNGs and individual PNG/PDF pages."""

import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tasks/resistor_network/src")]
os.environ.setdefault("MPLCONFIGDIR", "/tmp/resistor-v3-matplotlib")

# Bootstrap the environment and select a headless backend before pyplot.
# ruff: noqa: E402, T201
import matplotlib as mpl

mpl.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx
from matplotlib.backends.backend_pdf import PdfPages
from resistor_network.visualize import draw_topology

OUT = ROOT / "tasks/resistor_network/figures/v3"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    with PdfPages(OUT / "all_circuits.pdf") as pdf:
        for level in (1, 2):
            directory = (
                ROOT / f"tasks/resistor_network/environments/level_{level}/tasks_json"
            )
            tasks = [
                json.loads(path.read_text())[0]
                for path in sorted(directory.glob("*.json"))
            ]
            overview, axes = plt.subplots(2, 5, figsize=(30, 14))
            overview.suptitle(
                f"Resistor network v3 · Level {level} · All ten circuits", fontsize=24
            )
            (OUT / f"level_{level}").mkdir(exist_ok=True)
            for task, overview_ax in zip(tasks, axes.flat, strict=True):
                topology = task["scoring_params"]["expected_topology"]
                graph = nx.Graph([c[:2] for c in topology["connections"]])
                title = f"{task['id']} · {len(topology['resistors'])} resistors · {len(graph)} nodes"
                draw_topology(topology, ax=overview_ax, title=title, show_values=False)
                fig = plt.figure(figsize=(15, 11), layout="constrained")
                grid = fig.add_gridspec(1, 2, width_ratios=[3.1, 1])
                graph_ax, table_ax = fig.add_subplot(grid[0]), fig.add_subplot(grid[1])
                draw_topology(topology, ax=graph_ax, show_values=False)
                fig.suptitle(
                    f"Resistor network v3 · Level {level} · {title}", fontsize=19
                )
                cycles = graph.number_of_edges() - graph.number_of_nodes() + 1
                graph_ax.set_title(
                    f"{cycles} independent cycles · A/B terminals in orange",
                    fontsize=11,
                )
                rows = sorted(topology["connections"], key=lambda c: int(c[2][1:]))
                table = table_ax.table(
                    cellText=[
                        [rid, f"{a}-{b}", f"{topology['resistors'][rid]:.6f}"]
                        for a, b, rid in rows
                    ],
                    colLabels=["ID", "Nodes", "Ohms"],
                    loc="center",
                    cellLoc="left",
                    colWidths=[0.18, 0.32, 0.50],
                )
                table.auto_set_font_size(False)
                table.set_fontsize(8.5)
                table.scale(1, 1.22)
                for (row, _column), cell in table.get_celld().items():
                    cell.set_edgecolor("#d9e2e8")
                    cell.set_facecolor(
                        "#e8f0f5" if row == 0 else ("#f5f8fa" if row % 2 else "white")
                    )
                    if row == 0:
                        cell.set_text_props(weight="bold")
                table_ax.set_axis_off()
                fig.savefig(
                    OUT / f"level_{level}/{task['id']}.png",
                    dpi=180,
                    bbox_inches="tight",
                )
                pdf.savefig(fig, bbox_inches="tight")
                plt.close(fig)
            overview.tight_layout(rect=(0, 0, 1, 0.96))
            overview.savefig(
                OUT / f"level_{level}_overview.png", dpi=160, bbox_inches="tight"
            )
            plt.close(overview)
            print(f"Plotted level {level}", flush=True)
    print(OUT / "all_circuits.pdf")


if __name__ == "__main__":
    main()
