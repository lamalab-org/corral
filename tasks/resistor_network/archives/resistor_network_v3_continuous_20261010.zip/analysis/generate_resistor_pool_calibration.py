"""Pair a frozen continuous bank with a published pool of 30 allowed values.

Preserve topology and observed node pairs, quantize hidden values, then
recompute all readings and audits. Never overwrite the source or output bank.
"""

import argparse
import hashlib
import json
import math
import random
import sys
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "tasks/resistor_network/src")]
# ruff: noqa: E402, T201
from resistor_network.env import get_scoring_function, load_tasks_from_json
from resistor_network.sampler import (
    _jacobian_rank,
    _measurement_jacobian,
    find_non_load_bearing_resistors,
    measure_pairs,
    rounding_stability,
)
from resistor_network.sparse import audit_sparse_ambiguity, fit_known_wiring

POOL30 = (
    10,
    11,
    12,
    14,
    15,
    17,
    19,
    21,
    23,
    25,
    28,
    31,
    35,
    38,
    42,
    47,
    52,
    58,
    64,
    71,
    79,
    88,
    97,
    108,
    119,
    132,
    147,
    163,
    180,
    200,
)


def nearest(value):
    return min(POOL30, key=lambda candidate: abs(math.log(candidate / value)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise SystemExit(f"Refusing to overwrite existing bank: {args.output}")
    assert len(set(POOL30)) == 30
    paths = sorted(args.source.glob("level_*/tasks_json/task_*.json"))
    if len(paths) != 6:
        raise SystemExit("Expected six source calibration tasks")
    args.output.mkdir(parents=True)
    manifest = {
        "bank": "resistor_network_calibration_pool30_20261010",
        "source_bank": str(args.source.resolve()),
        "value_pool": POOL30,
        "repeats_allowed": True,
        "pairing": "Same labeled wiring, sizes, and observed pairs; values mapped to nearest pool value in log space; readings recomputed.",
        "tasks": [],
    }
    for source in paths:
        task = json.loads(source.read_text())[0]
        truth = task["scoring_params"]["expected_topology"]
        truth["resistors"] = {
            rid: nearest(value) for rid, value in truth["resistors"].items()
        }
        pairs = [
            (m["node_a"], m["node_b"]) for m in task["initial_input"]["measurements"]
        ]
        readings = measure_pairs(truth, pairs)
        task["initial_input"]["measurements"] = readings
        task["initial_input"]["notes"].append(
            f"Each resistor must have a value from this list (ohms): {list(POOL30)}. Values may repeat; the number of resistors of each value is not provided."
        )
        task["scoring_params"].update(
            expected_measurements=readings, allowed_resistor_values=list(POOL30)
        )
        task["uuid"] = str(uuid.uuid4())
        count = len(truth["resistors"])
        rank = _jacobian_rank(_measurement_jacobian(truth, pairs))
        stability = rounding_stability(truth, pairs, value_pool=list(POOL30))
        assert rank == count
        assert stability["stable"]
        assert not find_non_load_bearing_resistors(truth, readings)
        scorer = get_scoring_function(task["scoring_function"], task["scoring_params"])
        assert scorer(json.dumps(truth)) == 1
        fitted = fit_known_wiring(truth, readings, respect_rounding=True)
        snapped = fitted["topology"]
        snapped["resistors"] = {
            rid: nearest(value) for rid, value in snapped["resistors"].items()
        }
        assert scorer(json.dumps(snapped)) == 1
        seed = 202610130 + task["level"] * 10 + int(task["id"].split("_")[1])
        audit = audit_sparse_ambiguity(random.Random(seed), truth, readings)
        audit["value_domain"] = (
            "Continuous superset; any witness is also checked after pool snapping. Not a discrete uniqueness proof."
        )
        if audit["witness"] is not None:
            witness = dict(audit["witness"])
            witness["resistors"] = {
                rid: nearest(value) for rid, value in witness["resistors"].items()
            }
            audit["snapped_pool_witness_score"] = scorer(json.dumps(witness))
        audit["rounding_stability"] = stability
        task["sampling_metadata"].update(
            bank=manifest["bank"],
            ambiguity_audit=audit,
            value_pool=list(POOL30),
            pairing_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
            known_wiring_pool_fit_score=1,
        )
        path = args.output / source.relative_to(args.source)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps([task], indent=2) + "\n")
        record = {
            "level": task["level"],
            "id": task["id"],
            "resistors": count,
            "measurements": len(readings),
            "jacobian_rank": rank,
            "ground_truth_score": 1,
            "known_wiring_pool_fit_score": 1,
            "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "path": str(path.relative_to(args.output)),
        }
        manifest["tasks"].append(record)
        print(json.dumps(record), flush=True)
    for level in (1, 2):
        assert (
            len(load_tasks_from_json(args.output / f"level_{level}" / "tasks_json"))
            == 3
        )
    (args.output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    main()
