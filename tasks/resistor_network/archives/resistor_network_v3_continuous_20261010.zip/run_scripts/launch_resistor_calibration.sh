#!/usr/bin/env bash
# Six frozen calibration tasks x four agents x one trial = 24 trials.
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export TASK_BANK_ROOT="${TASK_BANK_ROOT:-$REPO_ROOT/tasks/resistor_network/calibration/20261010}"
export OUT_ROOT="${OUT_ROOT:-/data/alamparan/corral_psychometric_runs/resistor_network_calibration_20261010}"
export RUN_PREFIX="${RUN_PREFIX:-resistor-calibration}"
export TAG="${TAG:-20261010}"
export BATCHES="${BATCHES:-A B}"
export LEVELS="1 2"
export TRIALS="${TRIALS:-1}"
export SMOKE="${SMOKE:-0}"
export MAX_PARALLEL="${MAX_PARALLEL:-2}"
export MAX_PARALLEL_PER_TASK=1
export REACT_MAX_TOKENS="${REACT_MAX_TOKENS:-16000}"
export REACT_REQUEST_TIMEOUT_S="${REACT_REQUEST_TIMEOUT_S:-600}"
export WALL_CLOCK_TIMEOUT_S="${WALL_CLOCK_TIMEOUT_S:-900}"
exec bash "$REPO_ROOT/run_scripts/launch_resistor_network.sh"
