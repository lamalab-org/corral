#!/usr/bin/env bash
# One task per level x four agents = eight paired value-pool smoke trials.
set -euo pipefail
REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export TASK_BANK_ROOT="$REPO_ROOT/tasks/resistor_network/calibration/20261010_pool30"
export OUT_ROOT=/data/alamparan/corral_psychometric_runs/resistor_network_calibration_pool30_20261010
export RUN_PREFIX=resistor-calibration-pool30
export SMOKE=1
export TRIALS=1
export BATCHES="A B"
exec bash "$REPO_ROOT/run_scripts/launch_resistor_calibration.sh"
