#!/usr/bin/env bash
# Launch the resistor_network agent x model matrix without a Docker sandbox, in
# provider-disjoint batches.
#
#   Batch A: react/gpt-5.6-sol (OpenAI), react/opus-5.5 (Anthropic)
#   Batch B: codex/gpt-5.6-sol (OpenAI), claude-code/opus-5.5 (Anthropic)
#   Batch C: react/kimi-k3, openhands/kimi-k3 (OpenRouter, pinned to Together)
#   Batch D: ai-scientist/opus-5.5 (8 planning + 8 experiment workers)
#
# Every (combo, level) run in a batch executes concurrently; a batch starts only
# after the previous one finishes. `--sandbox local` means corral's workspace
# `terminal` tool is not injected; harness-native tools (Claude Code, Codex,
# OpenHands) are unchanged.
#
# Usage (from the repo root):
#   run_scripts/launch_resistor_network.sh                 # batches A then B
#   BATCHES="C D" run_scripts/launch_resistor_network.sh   # Kimi + AI Scientist
#   ONLY=react-opus55 run_scripts/launch_resistor_network.sh
#   SMOKE=1 run_scripts/launch_resistor_network.sh         # 1 task x 1 trial per run
#   DRY_RUN=1 run_scripts/launch_resistor_network.sh       # print commands only
#
# Keys are read from .env by the corral CLI.
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$REPO_ROOT"

OUT_ROOT="${OUT_ROOT:-/data/alamparan/corral_psychometric_runs/resistor_network_v3}"
TRIALS="${TRIALS:-5}"
LEVELS="${LEVELS:-1 2}"
BATCHES="${BATCHES:-A B}"
ONLY="${ONLY:-}"
# Concurrent trials per run. Both levels run at once, so a batch of two combos
# keeps up to 4 x MAX_PARALLEL trials in flight (2 x MAX_PARALLEL per provider).
MAX_PARALLEL="${MAX_PARALLEL:-10}"
MAX_PARALLEL_PER_TASK="${MAX_PARALLEL_PER_TASK:-2}"
REASONING="${REASONING:-medium}"
TAG="${TAG:-$(date +%Y%m%d)}"
RUN_PREFIX="${RUN_PREFIX:-resistor-v3}"
# Optional separate bank, with level_N/tasks_json beneath it.
TASK_BANK_ROOT="${TASK_BANK_ROOT:-}"
REACT_MAX_TOKENS="${REACT_MAX_TOKENS:-}"
REACT_REQUEST_TIMEOUT_S="${REACT_REQUEST_TIMEOUT_S:-}"
SMOKE="${SMOKE:-0}"
DRY_RUN="${DRY_RUN:-0}"
# Optional harness timeouts (seconds); empty keeps the agent defaults.
OPENHANDS_TOOL_TIMEOUT_S="${OPENHANDS_TOOL_TIMEOUT_S:-}"
WALL_CLOCK_TIMEOUT_S="${WALL_CLOCK_TIMEOUT_S:-}"   # claude-code and codex
# Trials share the host, whose thread pools would otherwise size themselves from
# all 128 cores (OpenBLAS in the corral process, the codex tokio runtime).
POOL_THREADS="${POOL_THREADS:-2}"
for name in OMP_NUM_THREADS OPENBLAS_NUM_THREADS MKL_NUM_THREADS NUMEXPR_NUM_THREADS; do
  export "$name=$POOL_THREADS"
done
export TOKIO_WORKER_THREADS="${TOKIO_WORKER_THREADS:-4}"

KIMI_PROVIDER='{"only":["together"],"allow_fallbacks":false,"zdr":true,"data_collection":"deny"}'

with_timeout() {  # $1 = agent kwargs JSON, $2 = key, $3 = value
  if [[ -n "$3" ]]; then
    python3 -c 'import json,sys; d=json.loads(sys.argv[1]); d[sys.argv[2]]=float(sys.argv[3]); print(json.dumps(d))' "$1" "$2" "$3"
  else
    printf '%s' "$1"
  fi
}

with_react_limits() {
  python3 - "$1" "$REACT_MAX_TOKENS" "$REACT_REQUEST_TIMEOUT_S" <<'PY'
import json, sys
d = json.loads(sys.argv[1])
if sys.argv[2]:
    d['max_tokens'] = int(sys.argv[2])
if sys.argv[3]:
    d['timeout'] = float(sys.argv[3])
print(json.dumps(d))
PY
}

# key|batch|agent|model|agent-kwargs JSON|extra bench args (override defaults)
# react forwards kwargs verbatim to litellm.acompletion, so provider routing goes
# in LiteLLM's `extra_body`; OpenHands consumes `litellm_extra_body` instead.
COMBOS=(
  "react-gpt56sol|A|react|openai/gpt-5.6-sol|$(with_react_limits "{\"reasoning_effort\":\"$REASONING\",\"additional_drop_params\":[\"temperature\"]}")"
  "react-opus55|A|react|anthropic/claude-opus-5-5|$(with_react_limits "{\"reasoning_effort\":\"$REASONING\"}")"
  "codex-gpt56sol|B|codex|gpt-5.6-sol|$(with_timeout "{\"reasoning_effort\":\"$REASONING\"}" wall_clock_timeout_s "$WALL_CLOCK_TIMEOUT_S")"
  "claudecode-opus55|B|claude-code|claude-opus-5-5|$(with_timeout "{\"reasoning_effort\":\"$REASONING\"}" wall_clock_timeout_s "$WALL_CLOCK_TIMEOUT_S")"
  "react-kimik3|C|react|openrouter/moonshotai/kimi-k3|{\"reasoning_effort\":\"$REASONING\",\"extra_body\":{\"provider\":$KIMI_PROVIDER}}"
  "openhands-kimik3|C|openhands|openrouter/moonshotai/kimi-k3|$(with_timeout "{\"reasoning_effort\":\"$REASONING\",\"litellm_extra_body\":{\"provider\":$KIMI_PROVIDER}}" tool_timeout_s "$OPENHANDS_TOOL_TIMEOUT_S")"
  # Matches the psychometrics aiscientist16 profile. Each trial runs 8 concurrent
  # experiment workers, hence the lower default trial concurrency.
  "aiscientist16-opus55|D|ai-scientist|anthropic/claude-opus-5-5|{\"reasoning_effort\":\"$REASONING\",\"timeout\":180,\"config\":{\"parallel_llm_workers\":8,\"parallel_experiment_workers\":8,\"candidates_per_expansion\":4,\"parallel_parent_selection\":true,\"preliminary_node_budget\":4,\"tuning_node_budget\":2,\"research_node_budget\":5,\"verification_node_budget\":5,\"max_tool_calls\":64}}|--max-iterations 100 --max-parallel ${AISCI_MAX_PARALLEL:-5}"
)

TASK_ARGS=()
if [[ "$SMOKE" == "1" ]]; then
  TRIALS=1
  TASK_ARGS=(--task task_0)
  OUT_ROOT="$OUT_ROOT/smoke"
  TAG="$TAG-smoke"
fi
LOG_DIR="$OUT_ROOT/logs"
[[ "$DRY_RUN" == "1" ]] || mkdir -p "$LOG_DIR"

# Without Docker every trial runs from the task's own environment
# (tasks/resistor_network/.venv), which holds the task package and, installed
# once with `uv pip install -e '../..[codex,claude,openhands,langfuse]'`, the
# agent harness extras. `--no-sync` keeps uv from pruning those extras.
UV_RUN=(env -u VIRTUAL_ENV uv run --no-sync --project tasks/resistor_network)
if [[ "$DRY_RUN" != "1" ]]; then
  "${UV_RUN[@]}" python -c "import resistor_network, corral.agents.codex, corral.agents.claude_code, corral.agents.openhands" >/dev/null 2>&1 \
    || { echo "task environment is missing the task package or agent extras" >&2; exit 1; }
fi

run_level() {  # $1 key, $2 agent, $3 model, $4 kwargs, $5 extra args, $6 level
  local key="$1" agent="$2" model="$3" kwargs="$4" level="$6" run_id
  local -a extra=()
  read -r -a extra <<<"$5"
  run_id="${RUN_PREFIX}-l${level}-${key}-k${TRIALS}-${TAG}"
  local env_kwargs="{\"level\": $level}"
  if [[ -n "$TASK_BANK_ROOT" ]]; then
    env_kwargs="$(python3 -c 'import json,sys; print(json.dumps({"level": int(sys.argv[1]), "task_json_path": sys.argv[2]}))' "$level" "$TASK_BANK_ROOT/level_${level}/tasks_json")"
  fi
  local cmd=(
    "${UV_RUN[@]}" corral bench
    --environment resistor_network
    --env-kwargs "$env_kwargs"
    --agent "$agent"
    --model "$model"
    --agent-kwargs "$kwargs"
    --trials "$TRIALS"
    --max-parallel "$MAX_PARALLEL"
    --max-parallel-per-task "$MAX_PARALLEL_PER_TASK"
    --sandbox local
    --verbose
    --run-id "$run_id"
    --output-dir "$OUT_ROOT/level_${level}"
    "${TASK_ARGS[@]}"
    "${extra[@]}"
  )
  if [[ "$DRY_RUN" == "1" ]]; then
    printf '%q ' "${cmd[@]}"; echo; return 0
  fi
  echo "[$(date -Is)] start $run_id -> $LOG_DIR/$run_id.log"
  if CORRAL_LOG_FILE="$LOG_DIR/$run_id.corral.log" "${cmd[@]}" >"$LOG_DIR/$run_id.log" 2>&1; then
    echo "[$(date -Is)] done  $run_id"
  else
    local status=$?
    echo "[$(date -Is)] FAIL  $run_id (exit $status, see $LOG_DIR/$run_id.log)"
    return "$status"
  fi
}

overall=0
for batch in $BATCHES; do
  pids=()
  for combo in "${COMBOS[@]}"; do
    IFS='|' read -r key b agent model kwargs extra_args <<<"$combo"
    [[ "$b" == "$batch" ]] || continue
    [[ -z "$ONLY" || " $ONLY " == *" $key "* ]] || continue
    for level in $LEVELS; do
      run_level "$key" "$agent" "$model" "$kwargs" "$extra_args" "$level" &
      pids+=("$!")
    done
  done
  [[ ${#pids[@]} -gt 0 ]] || continue
  echo "[$(date -Is)] batch $batch: waiting on ${#pids[@]} run(s)"
  for pid in "${pids[@]}"; do wait "$pid" || overall=1; done
done
exit "$overall"
